# -*- coding: utf-8 -*-
import maya.cmds as cmds

import maya.OpenMaya as om
import sys
import os
import importlib
import math

# --------------------------------------------------------------------------
# ScriptName : MM_tool_Collider
# Contents   : Create primitives based on bounding box of selection
# Author     : MM (Converted to Python by Assistant, Renamed by User Request)
# Since      : 2021/07 (Python Ver: 2025/01)
# --------------------------------------------------------------------------

class MM_tool_Collider:
    def __init__(self):
        self.window_name = "MM_tool_Collider"
        self.ui_cube_int = [None, None, None]
        self.ui_cylinder_int = [None, None, None]
        self.ui_sphere_int = [None, None]

        self.ui_radio_collection = None
        self.ui_world_radio = None
        self.ui_local_radio = None
        self.ui_one_obj_cb = None
        self.ui_inflate_cb = None
        self.ui_inflate_val_menu = None
        self.last_create = []

    def validate_slider_step(self, control):
        """Snaps the slider value to the allowed steps."""
        allowed_steps = [6, 8, 12, 16, 32, 64]
        current_val = cmds.intSliderGrp(control, q=True, v=True)
        
        closest_val = allowed_steps[0]
        min_diff = abs(current_val - allowed_steps[0])
        
        for step in allowed_steps:
            diff = abs(current_val - step)
            if diff < min_diff:
                min_diff = diff
                closest_val = step
        
        # If the value is strictly greater than the largest step, snap to largest
        if current_val > allowed_steps[-1]:
            closest_val = allowed_steps[-1]
            
        cmds.intSliderGrp(control, e=True, v=closest_val)


    def number_10_to_2(self, number):
        """Converts decimal to binary array (simulated as int array for MEL compatibility)"""
        bool_list = [0] * 21
        baisu = pow(2, 20)
        remainder = number
        
        for i in range(20, -1, -1):
            if remainder - baisu >= 0:
                remainder = remainder - baisu
                bool_list[i] = 1
            else:
                bool_list[i] = 0
            baisu = baisu / 2
        return bool_list

    def number_2_to_10(self, bool_list):
        """Converts binary array to decimal"""
        number = 0
        baisu = 1
        for i in range(len(bool_list)):
            number += baisu * bool_list[i]
            baisu = baisu * 2
        return number

    def min_max(self, ver_list, world_true):
        """Calculates min/max bounds of vertex list"""
        if not ver_list:
            return [0.0] * 6
            
        points = []
        for ver in ver_list:
            if world_true:
                pos = cmds.pointPosition(ver, w=True)
            else:
                pos = cmds.pointPosition(ver, l=True)
            points.append(pos)
            
        if not points:
            return [0.0] * 6

        min_x = max_x = points[0][0]
        min_y = max_y = points[0][1]
        min_z = max_z = points[0][2]

        for p in points:
            if p[0] < min_x: min_x = p[0]
            if p[0] > max_x: max_x = p[0]
            if p[1] < min_y: min_y = p[1]
            if p[1] > max_y: max_y = p[1]
            if p[2] < min_z: min_z = p[2]
            if p[2] > max_z: max_z = p[2]

        return [min_x, min_y, min_z, max_x, max_y, max_z]

    def get_select_to_transform_list(self):
        transform_list = cmds.ls(sl=True, tr=True) or []
        selects = cmds.ls(sl=True) or []
        
        # Remove transforms from selects to get components
        del_tf = [s for s in selects if s not in transform_list]
        
        vertex_list = cmds.polyListComponentConversion(del_tf, tv=True) or []
        shapes = cmds.polyListComponentConversion(vertex_list) or []
        shape_to_tf = cmds.listRelatives(shapes, p=True, pa=True, type="transform") or []
        
        expanded_transforms = []
        
        for tf in transform_list:
            
            # 1. Check if the selected transform itself is a mesh (has mesh shape)
            s = cmds.listRelatives(tf, s=True, ni=True, pa=True)
            if s:
                for shape in s:
                    if cmds.nodeType(shape) == "mesh":
                        expanded_transforms.append(tf)
                        break
            
            # 2. Search for descendants.
            # Debug showed s=True can fail. Get ALL descendants and filter manually.
            all_descendants = cmds.listRelatives(tf, ad=True, pa=True)
            
            if all_descendants:
                for node in all_descendants:
                    # Retrieve node type. 
                    if cmds.nodeType(node) == "mesh":
                        # Check if it is an intermediate object (if needed) but usually 'mesh' is fine
                        # If we want to be strict about noIntermediate, we can check property
                        # but usually just checking type is enough for this tool
                        if not cmds.getAttr(node + ".intermediateObject"):
                            # Get parent transform
                            parents = cmds.listRelatives(node, p=True, pa=True)
                            if parents:
                                expanded_transforms.append(parents[0])

        # Combine component-derived transforms and expanded transforms from selection
        # unique list
        target_transform_list = list(set(expanded_transforms + shape_to_tf))
        return target_transform_list

    def get_select_to_vertex_list(self):
        select_list = cmds.ls(sl=True) or []
        check_ver_list = cmds.filterExpand(select_list, sm=31) or [] # 31: Mask for polygon vertices
        
        select_edge_list = cmds.filterExpand(select_list, sm=32) or []
        if select_edge_list or not check_ver_list:
            works = cmds.polyListComponentConversion(select_edge_list, tv=True)
            works = cmds.filterExpand(works, sm=31)
            if works:
                check_ver_list = works

        select_face_list = cmds.filterExpand(select_list, sm=34) or []
        if select_face_list or not check_ver_list:
            works = cmds.polyListComponentConversion(select_face_list, tv=True)
            works = cmds.filterExpand(works, sm=31)
            if works:
                check_ver_list = works
                
        return check_ver_list or []

    def get_list_num(self, obj):
        parents = cmds.listRelatives(obj, p=True, pa=True)
        if not parents:
            children = cmds.ls(assemblies=True)
        else:
            children = cmds.listRelatives(parents[0], c=True, pa=True)
            
        if not children:
            return 0
            
        for i, child in enumerate(children):
            # Simple check, might need full path comparison
            if child == obj or child.split("|")[-1] == obj.split("|")[-1]:
                return i
        return 0

    def get_seven_position(self, obj, transform_list, check_ver_list, world_true):
        group_true = False
        ver_list = []
        
        # Check if obj is in plain transform list selection
        # (Compare by name, handle potential full paths)
        is_obj_selected = False
        if transform_list:
            for t in transform_list:
                if t == obj or t.split("|")[-1] == obj.split("|")[-1]:
                    is_obj_selected = True
                    break
                
                # Check if obj is a descendant of t (Group Selection Support)
                long_t = cmds.ls(t, l=True)
                long_obj = cmds.ls(obj, l=True)
                if long_t and long_obj:
                    # Append pipe to ensure we match directory-style hierarchy, avoiding partial name matches (e.g. group1 vs group10)
                    if long_obj[0].startswith(long_t[0] + "|"):
                        is_obj_selected = True
                        break
        
        if is_obj_selected:
            ver_list = cmds.polyListComponentConversion(obj, tv=True)
            ver_list = cmds.filterExpand(ver_list, sm=31)
            shape_list = cmds.listRelatives(obj, c=True, s=True)
            if not shape_list:
                group_true = True
        else:
            if check_ver_list:
                # Naive prefix check as in MEL
                for ver in check_ver_list:
                    if ver.startswith(obj):
                        ver_list.append(ver)

        bound_pos = [0.0] * 6
        piv_pos = [0.0, 0.0, 0.0]

        if not world_true and group_true:
            # Safe Logic: Calculate Local Bounding Box using Matrices
            # Get Group's World Inverse Matrix
            m_list = cmds.xform(obj, q=True, m=True, ws=True)
            m_matrix = om.MMatrix()
            om.MScriptUtil.createMatrixFromList(m_list, m_matrix)
            inv_matrix = m_matrix.inverse()
            
            # Get all descendant mesh vertices in World Space
            shapes = cmds.listRelatives(obj, ad=True, s=True, pa=True, type="mesh")
            
            min_x = min_y = min_z = float('inf')
            max_x = max_y = max_z = float('-inf')
            found_points = False
            
            if shapes:
                for shape in shapes:
                    try:
                        sel = om.MSelectionList()
                        sel.add(shape)
                        dag = om.MDagPath()
                        sel.getDagPath(0, dag)
                        mesh_fn = om.MFnMesh(dag)
                        points = om.MPointArray()
                        mesh_fn.getPoints(points, om.MSpace.kWorld)
                        
                        for i in range(points.length()):
                            w_pt = points[i]
                            # Multiply by Inverse Matrix to get Local pos relative to Group
                            l_pt = w_pt * inv_matrix
                            
                            if l_pt.x < min_x: min_x = l_pt.x
                            if l_pt.x > max_x: max_x = l_pt.x
                            if l_pt.y < min_y: min_y = l_pt.y
                            if l_pt.y > max_y: max_y = l_pt.y
                            if l_pt.z < min_z: min_z = l_pt.z
                            if l_pt.z > max_z: max_z = l_pt.z
                            found_points = True
                    except:
                        continue
            
            if found_points:
                bound_pos = [min_x, min_y, min_z, max_x, max_y, max_z]
            
            # For pivot, since we are in the group's local space, the pivot is effectively the origin
            # or whatever the local pivot is set to.
            # The original logic used `xform -q -piv` which in local space is the pivot offset.
            pos = cmds.xform(obj, q=True, piv=True)
            piv_pos = [pos[0], pos[1], pos[2]]

        else:
            bound_pos = self.min_max(ver_list, world_true)
            
            if world_true:
                pos = cmds.xform(obj, q=True, ws=True, piv=True)
                piv_pos = [pos[0], pos[1], pos[2]]
            else:
                pos = cmds.xform(obj, q=True, piv=True)
                piv_pos = [pos[0], pos[1], pos[2]]

        center = [
            (bound_pos[0] + bound_pos[3]) * 0.5,
            (bound_pos[1] + bound_pos[4]) * 0.5,
            (bound_pos[2] + bound_pos[5]) * 0.5
        ]
        scale = [
            (bound_pos[3] - bound_pos[0]),
            (bound_pos[4] - bound_pos[1]),
            (bound_pos[5] - bound_pos[2])
        ]
        
        # Construct list (simulating vector array from MEL)
        position_list = []
        position_list.append([bound_pos[0], piv_pos[1], piv_pos[2]]) # 0
        position_list.append([piv_pos[0], bound_pos[1], piv_pos[2]]) # 1
        position_list.append([piv_pos[0], piv_pos[1], bound_pos[2]]) # 2
        position_list.append([bound_pos[3], piv_pos[1], piv_pos[2]]) # 3
        position_list.append([piv_pos[0], bound_pos[4], piv_pos[2]]) # 4
        position_list.append([piv_pos[0], piv_pos[1], bound_pos[5]]) # 5
        position_list.append(piv_pos) # 6
        position_list.append(center)  # 7
        position_list.append([center[0], piv_pos[1], piv_pos[2]]) # 8
        position_list.append([piv_pos[0], center[1], piv_pos[2]]) # 9
        position_list.append([piv_pos[0], piv_pos[1], center[2]]) # 10
        position_list.append(scale) # 11
        
        return position_list


    def get_obb_from_min_volume(self, targets, components=None):
        """
        Calculates OBB using Face Alignment (Minimum Volume) method.
        targets: list of object names (strings)
        components: list of component names (strings) - e.g. ["pCube1.f[0]", "pCube1.f[1]"]
        """
        try:
            if isinstance(targets, str):
                targets = [targets]

            target_list = []
            process_components = False

            if components:
                target_list = components
                process_components = True
            else:
                # Collect all mesh shapes (recursive)
                all_shapes = []
                # Direct shapes
                s1 = cmds.listRelatives(targets, s=True, pa=True, f=True)
                if s1: all_shapes.extend(s1)
                # Descendants
                s2 = cmds.listRelatives(targets, ad=True, s=True, pa=True, f=True)
                if s2: all_shapes.extend(s2)
                
                # Filter for meshes and unique, exclude intermediate objects (hidden history)
                mesh_shapes = cmds.ls(all_shapes, type="mesh", l=True, ni=True) or []
                target_list = list(set(mesh_shapes))
            
            if not target_list:
                return None
                
            all_points = om.MPointArray()
            candidate_alignments = []
            unique_normals = []
            max_faces_to_check = 50 
            total_face_count = 0
            
            for item in target_list:
                sel = om.MSelectionList()
                try:
                    sel.add(item)
                except:
                    continue
                    
                dag_path = om.MDagPath()
                component = om.MObject()
                sel.getDagPath(0, dag_path, component)
                
                # Check for mesh type just in case
                if dag_path.apiType() != om.MFn.kMesh and dag_path.apiType() != om.MFn.kTransform:
                    continue
                
                # If it's a transform, extend to shape
                if dag_path.apiType() == om.MFn.kTransform:
                    dag_path.extendToShape()

                mesh_fn = om.MFnMesh(dag_path)
                points = om.MPointArray()
                mesh_fn.getPoints(points, om.MSpace.kWorld)
                
                # Collect points and potential axes
                if not component.isNull():
                    # Component Mode: Iterate faces to get points AND axes
                    face_it = om.MItMeshPolygon(dag_path, component)
                    
                    while not face_it.isDone():
                        # Always collect points from the selected faces
                        p_arr = om.MPointArray()
                        face_it.getPoints(p_arr, om.MSpace.kWorld)
                        for i in range(p_arr.length()):
                            all_points.append(p_arr[i])

                        # Collect axes if under limit
                        if total_face_count <= max_faces_to_check:
                            normal = om.MVector()
                            face_it.getNormal(normal, om.MSpace.kWorld)
                            norm_key = (round(normal.x, 3), round(normal.y, 3), round(normal.z, 3))
                            
                            if norm_key not in unique_normals:
                                unique_normals.append(norm_key)
                                
                                # Basis X = Normal
                                axis_x = om.MVector(normal)
                                axis_x.normalize()
                                
                                # Need an orthogonal vector (Basis Y)
                                edges = om.MIntArray()
                                face_it.getEdges(edges)
                                
                                verts = om.MIntArray()
                                face_it.getVertices(verts)
                                
                                if verts.length() >= 2:
                                     p1 = om.MPoint()
                                     p2 = om.MPoint()
                                     # We need positions of these vertices. 
                                     # Could use saved points or get again. 
                                     # p_arr has points in order of vertices for this face? 
                                     # Yes, getPoints returns points corresponding to polygon vertices.
                                     if p_arr.length() >= 2:
                                         p1 = p_arr[0]
                                         p2 = p_arr[1]
                                         
                                         edge_vec = om.MVector(p2.x - p1.x, p2.y - p1.y, p2.z - p1.z)
                                         edge_vec.normalize()
                                         
                                         y_proj = edge_vec - (axis_x * (edge_vec * axis_x))
                                         if y_proj.length() > 0.001:
                                             y_proj.normalize()
                                             axis_y = y_proj
                                             
                                             axis_z = axis_x ^ axis_y
                                             axis_z.normalize()
                                             
                                             candidate_alignments.append([axis_x, axis_y, axis_z])
                        
                        face_it.next()
                        total_face_count += 1
                        
                else:
                    # Object Mode: Get all points efficiently
                    mesh_fn.getPoints(points, om.MSpace.kWorld)
                    
                    # Append points to all_points
                    for i in range(points.length()):
                        all_points.append(points[i])
                    
                    # Collect potential axes from faces
                    face_it = om.MItMeshPolygon(dag_path)
                    
                    while not face_it.isDone():
                        if total_face_count > max_faces_to_check:
                            break
                            
                        normal = om.MVector()
                        face_it.getNormal(normal, om.MSpace.kWorld)
                        norm_key = (round(normal.x, 3), round(normal.y, 3), round(normal.z, 3))
                        
                        if norm_key not in unique_normals:
                            unique_normals.append(norm_key)
                            
                            # Basis X = Normal
                            axis_x = om.MVector(normal)
                            axis_x.normalize()
                            
                            # Need an orthogonal vector (Basis Y)
                            edges = om.MIntArray()
                            face_it.getEdges(edges)
                            
                            verts = om.MIntArray()
                            face_it.getVertices(verts)
                            
                            if verts.length() >= 2:
                                 p1 = points[verts[0]]
                                 p2 = points[verts[1]]
                                 edge_vec = om.MVector(p2.x - p1.x, p2.y - p1.y, p2.z - p1.z)
                                 edge_vec.normalize()
                                 
                                 y_proj = edge_vec - (axis_x * (edge_vec * axis_x))
                                 if y_proj.length() > 0.001:
                                     y_proj.normalize()
                                     axis_y = y_proj
                                     
                                     axis_z = axis_x ^ axis_y
                                     axis_z.normalize()
                                     
                                     candidate_alignments.append([axis_x, axis_y, axis_z])
                        
                        face_it.next()
                        total_face_count += 1
            
            num_points = all_points.length()
            if num_points < 3:
                return None

                

            best_vol = float('inf')
            best_basis = None
            best_min = None
            best_max = None
            
            for axes in candidate_alignments:
                # Project all points
                min_v = [float('inf')] * 3
                max_v = [float('-inf')] * 3
                
                for i in range(num_points):
                    p = all_points[i]
                    v_p = om.MVector(p.x, p.y, p.z)
                    
                    # Projection: Dot product
                    # x_local = v_p . axes[0]
                    for k in range(3):
                         # Note: This projection is effectively [Local = P * RotationMatrix^T]
                         # since Axes are rows of RotMat if we project directly.
                         val = v_p * axes[k]
                         if val < min_v[k]: min_v[k] = val
                         if val > max_v[k]: max_v[k] = val
                         
                vol = (max_v[0] - min_v[0]) * (max_v[1] - min_v[1]) * (max_v[2] - min_v[2])
                
                if vol < best_vol:
                    best_vol = vol
                    best_basis = axes
                    best_min = min_v
                    best_max = max_v
                    
            # Compute Final OBB Data
            axes = best_basis
            basis_center = [(best_min[k] + best_max[k]) * 0.5 for k in range(3)]
            basis_size = [best_max[k] - best_min[k] for k in range(3)]
            
            # Convert Basis Center to World
            world_center = om.MVector(0,0,0)
            for k in range(3):
                world_center += axes[k] * basis_center[k]
                
            # Unit Conversion
            # Current internal units are centimeters. Convert to UI units.
            # Use OpenMaya MDistance for robust conversion
            
            final_center = []
            for k in range(3):
                d = om.MDistance(world_center[k], om.MDistance.kCentimeters)
                final_center.append(d.asUnits(om.MDistance.uiUnit()))
                
            final_scale = []
            for k in range(3):
                d = om.MDistance(basis_size[k], om.MDistance.kCentimeters)
                final_scale.append(d.asUnits(om.MDistance.uiUnit()))
            
            # Rotation
            util = om.MScriptUtil()
            
            # Create Matrix: Axes as Rows (X, Y, Z)
            # R = [X
            #      Y
            #      Z] 
            # Because P_local = R * P_world (roughly) 
            # Wait, if we want the object to have this rotation:
            # The object's X axis will be aligned with 'axes[0]'.
            # The Matrix should transforms (1,0,0) to axes[0].
            # So Axes should be COLUMNS.
            # But earlier I used Rows?
            # Let's check:
            # mm[0]=x.x, mm[1]=x.y, mm[2]=x.z (Row 0)
            # If Row 0 is X axis, then [1,0,0] * M = [x.x, x.y, x.z]. Correct for Point * Matrix.
            
            mm = list([1.0 if i==j else 0.0 for i in range(4) for j in range(4)])
            
            mm[0] = axes[0].x; mm[1] = axes[0].y; mm[2] = axes[0].z
            mm[4] = axes[1].x; mm[5] = axes[1].y; mm[6] = axes[1].z
            mm[8] = axes[2].x; mm[9] = axes[2].y; mm[10] = axes[2].z
            
            m_matrix = om.MMatrix()
            om.MScriptUtil.createMatrixFromList(mm, m_matrix)
            
            transform_matrix = om.MTransformationMatrix(m_matrix)
            rot = transform_matrix.eulerRotation()
            rot_deg = [math.degrees(rot.x), math.degrees(rot.y), math.degrees(rot.z)]
            
            return {
                'center': final_center,
                'scale': final_scale,
                'rotation': rot_deg
            }
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return None
            
        except Exception as e:
            # cmds.warning(f"OBB Calc failed: {e}")
            import traceback
            traceback.print_exc()
            return None

    def ex_history(self, obj, mode):
        history_true = False
        shapes = cmds.listRelatives(obj, s=True, pa=True)
        if not shapes:
            return False
            
        cubes = cmds.listConnections(shapes[0], s=True, p=True, type="polyCube")
        cylinders = cmds.listConnections(shapes[0], s=True, p=True, type="polyCylinder")
        spheres = cmds.listConnections(shapes[0], s=True, p=True, type="polySphere")
        
        if mode == 0 and cubes: history_true = True
        if mode == 1 and cylinders: history_true = True
        if mode == 2 and spheres: history_true = True
        return history_true

    def change_history(self, obj, prim_int, mode):
        axis_change_true = False
        ax = []
        sxyz = [0,0,0]
        
        if mode == 0:
            ax = cmds.polyCube(obj, q=True, ax=True)
            sxyz[0] = cmds.polyCube(obj, q=True, sx=True)
            sxyz[1] = cmds.polyCube(obj, q=True, sy=True)
            sxyz[2] = cmds.polyCube(obj, q=True, sz=True)
            if sxyz[0] == prim_int[0] and sxyz[1] == prim_int[1] and sxyz[2] == prim_int[2]:
                axis_change_true = True
        elif mode == 1:
            ax = cmds.polyCylinder(obj, q=True, ax=True)
            sxyz[0] = cmds.polyCylinder(obj, q=True, sx=True)
            sxyz[1] = cmds.polyCylinder(obj, q=True, sy=True)
            sxyz[2] = cmds.polyCylinder(obj, q=True, sz=True)
            if sxyz[0] == prim_int[0] and sxyz[1] == prim_int[1] and sxyz[2] == prim_int[2]:
                axis_change_true = True
        elif mode == 2:
            ax = cmds.polySphere(obj, q=True, ax=True)
            sxyz[0] = cmds.polySphere(obj, q=True, sx=True)
            sxyz[1] = cmds.polySphere(obj, q=True, sy=True)
            if sxyz[0] == prim_int[0] and sxyz[1] == prim_int[1]:
                axis_change_true = True
        
        if axis_change_true:
            new_ax = [0,0,0]
            if ax[1] == 1: new_ax = [1,0,0]
            if ax[0] == 1: new_ax = [0,0,1]
            if ax[2] == 1: new_ax = [0,1,0]
            
            if mode == 0: cmds.polyCube(obj, e=True, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2], ax=tuple(new_ax))
            if mode == 1: cmds.polyCylinder(obj, e=True, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2], ax=tuple(new_ax))
            if mode == 2: cmds.polySphere(obj, e=True, sx=prim_int[0], sy=prim_int[1], ax=tuple(new_ax))
        else:
            if mode == 0: cmds.polyCube(obj, e=True, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2])
            if mode == 1: cmds.polyCylinder(obj, e=True, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2])
            if mode == 2: cmds.polySphere(obj, e=True, sx=prim_int[0], sy=prim_int[1])
            
        return obj

    def ensure_collider_material(self, obj):
        if not cmds.objExists("Colliders_mt"):
            cmds.shadingNode("lambert", asShader=True, n="Colliders_mt")
            cmds.setAttr("Colliders_mt.color", 0, 0.5, 0, type="double3")
            cmds.setAttr("Colliders_mt.transparency", 0.75, 0.75, 0.75, type="double3")
            cmds.setAttr("Colliders_mt.ambientColor", 0, 0, 0, type="double3")
            cmds.setAttr("Colliders_mt.incandescence", 0, 0, 0, type="double3")
            cmds.setAttr("Colliders_mt.diffuse", 1.0)
            cmds.setAttr("Colliders_mt.refractions", 0)
            cmds.setAttr("Colliders_mt.refractiveIndex", 1.0)
            cmds.setAttr("Colliders_mt.refractionLimit", 6)
            
        if not cmds.objExists("Colliders_mtSG"):
            cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name="Colliders_mtSG")
            cmds.connectAttr("Colliders_mt.outColor", "Colliders_mtSG.surfaceShader", f=True)
            
        cmds.sets(obj, e=True, forceElement="Colliders_mtSG")

    def go(self, mode):
        cmds.undoInfo(openChunk=True)
        try:
            self.save_prefs()
            name_list = ["_pCube", "_pCylinder", "_pSphere"]
            poly_name = name_list[mode]
            
            world_mode = cmds.radioButton(self.ui_world_radio, q=True, sl=True)
            one_mode = cmds.checkBox(self.ui_one_obj_cb, q=True, v=True)
            best_fit_mode = (not world_mode) # Local = Best Fit Enabled
            
            cube_int = [1, 1, 1]
            cylinder_int = [
                cmds.intSliderGrp(self.ui_cylinder_int[0], q=True, v=True),
                1,
                1
            ]
            sphere_int = [
                cmds.intSliderGrp(self.ui_sphere_int[0], q=True, v=True),
                cmds.intSliderGrp(self.ui_sphere_int[1], q=True, v=True)
            ]
            
            prim_int = []
            if mode == 0: prim_int = cube_int
            if mode == 1: prim_int = cylinder_int
            if mode == 2: prim_int = sphere_int
            
            transform_list = cmds.ls(sl=True, tr=True) or []
            check_object_list = self.get_select_to_transform_list()
            check_ver_list = self.get_select_to_vertex_list()
            
            if not check_object_list:
                primitive_objs = []
                if mode == 2:
                    primitive_objs = cmds.polySphere(r=0.5, sx=prim_int[0], sy=prim_int[1], ax=(0,1,0), cuv=2, ch=1)
                    self.ensure_collider_material(primitive_objs[0])
                elif mode == 1:
                    primitive_objs = cmds.polyCylinder(r=0.5, h=1, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2], ax=(0,1,0), rcp=0, cuv=3, ch=1)
                    self.ensure_collider_material(primitive_objs[0])
                else:
                    primitive_objs = cmds.polyCube(w=1, h=1, d=1, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2], ax=(0,1,0), cuv=4, ch=1)
                    self.ensure_collider_material(primitive_objs[0])
                
                self.last_create = primitive_objs
                return
                
            if one_mode:
                # world_mode = True  <-- Removed to allow Local + 1 Mesh (Best Fit OBB)
                obj = check_object_list[0]
                check_object_list = [obj]
                selects = cmds.ls(sl=True)
                check_ver_list = cmds.polyListComponentConversion(selects, tv=True)
                check_ver_list = cmds.filterExpand(check_ver_list, sm=31)
                
            create_list = []
            
            for obj in check_object_list:
                change_true = False
                history_true = False
                
                # Simple check if obj is in last created list
                if obj in self.last_create:
                    change_true = True
                    history_true = self.ex_history(obj, mode)
                    
                prim_obj = None
                
                if not history_true:
                    seven_position = []
                    center = [0,0,0]
                    scale = [1,1,1]
                    use_obb = False
                    obb_data = None
                    
                    if not one_mode:
                        # Check if object is selected (not components)
                        is_obj_selected = False
                        
                        # New Logic: Check if obj is in transform_list OR is a descendant of something in transform_list
                        if transform_list:
                            if obj in transform_list:
                                is_obj_selected = True
                            else:
                                # Check heritage
                                all_parents = cmds.listRelatives(obj, ap=True, f=True) or []
                                # We need full path checking to be safe, but transform_list might be short names
                                # Let's try to match long names
                                transform_list_long = cmds.ls(transform_list, l=True)
                                obj_long = cmds.ls(obj, l=True)[0]
                                
                                for t_l in transform_list_long:
                                    if obj_long.startswith(t_l + "|"):
                                        is_obj_selected = True
                                        break
                        
                        # Check for component selection on this object
                        obj_components = []
                        if not is_obj_selected:
                            # If object itself is not selected, check if components are
                            # Filter specifically for faces as OBB needs faces
                            sel_faces = cmds.filterExpand(cmds.ls(sl=True, l=True) or [], sm=34)
                            if sel_faces:
                                # Match faces to current obj
                                # Check long name prefix or short name match
                                obj_long = cmds.ls(obj, l=True)[0]
                                for f in sel_faces:
                                    # f is full path like |group|pCube1|pCubeShape1.f[0]
                                    # obj might be pCube1 or |group|pCube1
                                    # simple check: if object name is in component path
                                    if obj_long in f or obj in f:
                                        obj_components.append(f)

                        # OBB Calculation (Only if World is OFF and (Object is selected OR Components are selected) AND Best Fit is ON)
                        if not world_mode and best_fit_mode and (is_obj_selected or obj_components):
                            if obj_components:
                                obb_data = self.get_obb_from_min_volume(None, components=obj_components)
                            else:
                                obb_data = self.get_obb_from_min_volume(obj)
                                
                            if obb_data:
                                center = obb_data['center']
                                scale = obb_data['scale']
                                use_obb = True
                        
                        if not use_obb:
                            seven_position = self.get_seven_position(obj, transform_list, check_ver_list, world_mode)
                            center = seven_position[7]
                            scale = seven_position[11]
                    else:
                        if best_fit_mode:
                            # Recalculate full list of objects for OBB
                            targets = self.get_select_to_transform_list()
                            
                            # Check for face selection
                            sel_faces = cmds.filterExpand(cmds.ls(sl=True, l=True) or [], sm=34)
                            
                            if sel_faces:
                                obb_data = self.get_obb_from_min_volume(None, components=sel_faces)
                            else:
                                obb_data = self.get_obb_from_min_volume(targets)

                            if obb_data:
                                center = obb_data['center']
                                scale = obb_data['scale']
                                use_obb = True
                                
                        if not use_obb:
                            minmax = self.min_max(check_ver_list, True)
                            scale = [
                                minmax[3] - minmax[0],
                                minmax[4] - minmax[1],
                                minmax[5] - minmax[2]
                            ]
                            center = [
                                minmax[0] + scale[0]/2,
                                minmax[1] + scale[1]/2,
                                minmax[2] + scale[2]/2
                            ]

                        
                    primitive_objs = []
                    if mode == 2:
                        primitive_objs = cmds.polySphere(r=0.5, sx=prim_int[0], sy=prim_int[1], ax=(0,1,0), cuv=2, ch=1)
                    elif mode == 1:
                        primitive_objs = cmds.polyCylinder(r=0.5, h=1, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2], ax=(0,1,0), rcp=0, cuv=3, ch=1)
                    else:
                        primitive_objs = cmds.polyCube(w=1, h=1, d=1, sx=prim_int[0], sy=prim_int[1], sz=prim_int[2], ax=(0,1,0), cuv=4, ch=1)
                        
                    prim_obj = primitive_objs[0]
                    self.ensure_collider_material(prim_obj)
                    cmds.move(center[0], center[1], center[2], prim_obj, os=True)
                    
                    # Naming logic
                    obj_name = obj
                    end_name = ""
                    for name in name_list:
                        if obj_name.endswith(name):
                            end_name = name
                    if end_name:
                        obj_name = obj_name[:-len(end_name)]

                    # Delete old object if replacing and no history
                    if change_true and not history_true:
                        cmds.delete(obj)
                    
                    prim_obj = cmds.rename(prim_obj, obj_name + poly_name)
                    
                    if use_obb and obb_data:
                        # Apply OBB Rotation
                        rot = obb_data['rotation']
                        cmds.rotate(rot[0], rot[1], rot[2], prim_obj, a=True, os=True)
                    elif not world_mode:
                        group = cmds.group(prim_obj, n="MM_tool_Collider_Group")
                        parents = cmds.parent(group, obj)
                        group = parents[0]
                        cmds.setAttr(group + ".rotate", 0,0,0, type="double3")
                        cmds.setAttr(group + ".scale", 1,1,1, type="double3")
                        cmds.setAttr(group + ".shear", 0,0,0, type="double3")
                        cmds.setAttr(group + ".translate", 0,0,0, type="double3")
                        cmds.setAttr(group + ".rotatePivotTranslate", 0,0,0, type="double3")
                        cmds.setAttr(group + ".scalePivotTranslate", 0,0,0, type="double3")
                        
                        primitive_objs = cmds.parent(prim_obj, w=True)
                        prim_obj = primitive_objs[0]
                        cmds.delete(group)
                        
                    if prim_obj and cmds.objExists(prim_obj):
                        try:
                            cmds.xform(prim_obj, s=(float(scale[0]), float(scale[1]), float(scale[2])), r=True)
                        except (ValueError, TypeError):
                            # Fallback if somehow they are still not valid floats
                            cmds.xform(prim_obj, s=(1,1,1), r=True)

                    # Inflation Logic
                    if cmds.checkBox(self.ui_inflate_cb, q=True, v=True):
                        val_idx = cmds.optionMenuGrp(self.ui_inflate_val_menu, q=True, sl=True) 
                        # 1-based index from menu: 1:+1.5m, 2:+1m, 3:+0.5m, 4:+0.1m, 5:+0.05m
                        # Map to direction strings expected by move_selected_faces
                        directions = ["plus_1", "plus_0.5", "plus_0.25", "plus_0.1", "plus_0.05"]
                        if 1 <= val_idx <= len(directions):
                            direction = directions[val_idx-1]
                            inf_mode = 'box' if mode == 0 else 'surface'
                            
                            # Select faces for the script to operate on
                            faces = cmds.polyListComponentConversion(prim_obj, tf=True)
                            cmds.select(faces, r=True)
                            
                            self.call_python_script(direction, mode_override=inf_mode)
                            
                            # Reselect object
                            cmds.select(prim_obj, r=True)
                
                if change_true:
                    if history_true:
                        self.change_history(obj, prim_int, mode)
                        prim_obj = obj
                
                self.ensure_collider_material(prim_obj)
                create_list.append(prim_obj)
            
            self.last_create = create_list
            if create_list:
                cmds.select(create_list)

        except Exception as e:
            cmds.warning(f"MM_tool_Collider でエラーが発生しました: {e}")
            import traceback
            traceback.print_exc()
        finally:
            cmds.undoInfo(closeChunk=True)
            
    def ui_change(self, *args):
        # Radio Buttons generally don't need enable/disable logic based on each other
        # One Mesh checkbox is independent now.
        pass

    def save_prefs(self):
        cylinder_int = [
            cmds.intSliderGrp(self.ui_cylinder_int[0], q=True, v=True),
            1,
            1
        ]
        sphere_int = [
            cmds.intSliderGrp(self.ui_sphere_int[0], q=True, v=True),
            cmds.intSliderGrp(self.ui_sphere_int[1], q=True, v=True)
        ]
        
        cmds.optionVar(iv=("MM_tool_Collider_CylinderIntX", cylinder_int[0]))
        
        cmds.optionVar(iv=("MM_tool_Collider_SphereIntX", sphere_int[0]))
        cmds.optionVar(iv=("MM_tool_Collider_SphereIntY", sphere_int[1]))
        
        cmds.optionVar(iv=("MM_tool_Collider_WorldInt", 0)) # Deprecated
        
        # Save selection based on which radio is selected
        axis_int = 1
        if cmds.radioButton(self.ui_local_radio, q=True, sl=True):
            axis_int = 2
        cmds.optionVar(iv=("MM_tool_Collider_AxisRadio", axis_int))
        cmds.optionVar(iv=("MM_tool_Collider_OneObjCB", int(cmds.checkBox(self.ui_one_obj_cb, q=True, v=True))))

        cmds.optionVar(iv=("MM_tool_Collider_InflateCB", int(cmds.checkBox(self.ui_inflate_cb, q=True, v=True))))
        cmds.optionVar(iv=("MM_tool_Collider_InflateVal", cmds.optionMenuGrp(self.ui_inflate_val_menu, q=True, sl=True)))

    def load_prefs(self, reset=False):
        cube_int = [1, 1, 1]
        cylinder_int = [8, 1, 1]
        sphere_int = [8, 8]
        int_array = [0, 0]
        axis_radio = 1
        one_obj_cb = 0
        inflate_cb = 0
        inflate_val = 3
        
        if not reset:
            if cmds.optionVar(exists="MM_tool_Collider_CylinderIntX"): cylinder_int[0] = cmds.optionVar(q="MM_tool_Collider_CylinderIntX")
            
            if cmds.optionVar(exists="MM_tool_Collider_SphereIntX"): sphere_int[0] = cmds.optionVar(q="MM_tool_Collider_SphereIntX")
            if cmds.optionVar(exists="MM_tool_Collider_SphereIntY"): sphere_int[1] = cmds.optionVar(q="MM_tool_Collider_SphereIntY")
            
            if cmds.optionVar(exists="MM_tool_Collider_WorldInt"):
                seve_int = cmds.optionVar(q="MM_tool_Collider_WorldInt")
                bool_list = self.number_10_to_2(seve_int)
                int_array[0] = bool_list[0]
                int_array[1] = bool_list[1]
            
            if cmds.optionVar(exists="MM_tool_Collider_AxisRadio"): axis_radio = cmds.optionVar(q="MM_tool_Collider_AxisRadio")
            if cmds.optionVar(exists="MM_tool_Collider_OneObjCB"): one_obj_cb = cmds.optionVar(q="MM_tool_Collider_OneObjCB")
            if cmds.optionVar(exists="MM_tool_Collider_InflateCB"): inflate_cb = cmds.optionVar(q="MM_tool_Collider_InflateCB")
            if cmds.optionVar(exists="MM_tool_Collider_InflateVal"): inflate_val = cmds.optionVar(q="MM_tool_Collider_InflateVal")
        
        cmds.intSliderGrp(self.ui_cylinder_int[0], e=True, v=cylinder_int[0])
        
        cmds.intSliderGrp(self.ui_sphere_int[0], e=True, v=sphere_int[0])
        cmds.intSliderGrp(self.ui_sphere_int[1], e=True, v=sphere_int[1])
        
        if axis_radio == 2:
            cmds.radioButton(self.ui_local_radio, e=True, sl=True)
        else:
            cmds.radioButton(self.ui_world_radio, e=True, sl=True)
            
        cmds.checkBox(self.ui_one_obj_cb, e=True, v=bool(one_obj_cb))
        
        self.ui_change()
        
        cmds.checkBox(self.ui_inflate_cb, e=True, v=bool(inflate_cb))
        cmds.optionMenuGrp(self.ui_inflate_val_menu, e=True, sl=inflate_val)
        self.inflate_ui_change()

    def inflate_ui_change(self, *args):
        en = cmds.checkBox(self.ui_inflate_cb, q=True, v=True)
        cmds.optionMenuGrp(self.ui_inflate_val_menu, e=True, en=en)

    def ui_change(self, *args):
        pass
        # Old logic removed

    def int_value_change(self, mode, field, value):
        if mode == 0: cmds.intSliderGrp(self.ui_cube_int[field], e=True, v=value)
        if mode == 1: cmds.intSliderGrp(self.ui_cylinder_int[field], e=True, v=value)
        if mode == 2: cmds.intSliderGrp(self.ui_sphere_int[field], e=True, v=value)

    def call_python_script(self, direction, mode_override=None):
        # Logic to find the script path relative to this script file
        try:
            # Try to resolve relative to this script
            current_file = __file__
            current_dir = os.path.dirname(current_file)
            if current_dir not in sys.path:
                sys.path.append(current_dir)
        except NameError:
            # Variable __file__ might not be defined if running from Script Editor context directly (rare for module)
            pass
            
        try:
            import move_selected_faces
            importlib.reload(move_selected_faces)
            move_selected_faces.move_selected_faces(direction, mode_override)
        except ImportError:
            cmds.warning("MM_tool_Collider.py と同じディレクトリに move_selected_faces.py が見つかりません。")
        except Exception as e:
            cmds.warning(f"move_selected_faces の呼び出し中にエラーが発生しました: {e}")
            import traceback
            traceback.print_exc()

    def open_wiki(self, *args):
        import webbrowser
        webbrowser.open("https://kurosiro0112.github.io/MM_tool_Collider_wiki/guide/usage.html")

    def show_ui(self):
        if cmds.window(self.window_name, exists=True):
            cmds.deleteUI(self.window_name)
        
        self.window_name = cmds.window(self.window_name, title="MM_tool_Collider", tlb=True, rtf=True, w=180, h=500, menuBar=True)
        
        cmds.menu(label="ヘルプ", helpMenu=True)
        cmds.menuItem(label="マニュアル (Wiki)", c=self.open_wiki)

        # Force unit label to 'm' to ensure the tool always presents itself as working in meters
        unit_label = "m"
            
        label_sub_width = "幅の分割数"
        label_sub_height = "高さの分割数"
        label_sub_depth = "奥行きの分割数"
        label_sub_axis = "軸の分割数"
        label_sub_caps = "キャップの分割数"
        
        # Main Layout: ColumnLayout (No ScrollLayout to enforce minimum height and prevent hiding icons)
        # Using columnLayout prevents the window from shrinking smaller than content height on most platforms.
        main_layout = cmds.columnLayout(adj=True)
        
        # --- Top UI (Checkboxes) ---
        cmds.columnLayout(adj=True)
        
        # Inflate UI
        cmds.rowLayout(nc=2, adj=2)
        self.ui_inflate_cb = cmds.checkBox(l="生成時に膨張", cc=self.inflate_ui_change)
        self.ui_inflate_val_menu = cmds.optionMenuGrp(l="", cw=(1, 1))
        cmds.menuItem(l="+1" + unit_label)
        cmds.menuItem(l="+0.5" + unit_label)
        cmds.menuItem(l="+0.25" + unit_label)
        cmds.menuItem(l="+0.1" + unit_label)
        cmds.menuItem(l="+0.05" + unit_label)
        cmds.setParent("..")

        # World/Local (Radio) + OneObj (Checkbox)
        cmds.rowLayout(nc=3)
        self.ui_radio_collection = cmds.radioCollection()
        self.ui_world_radio = cmds.radioButton(l="ワールド", sl=True)
        self.ui_local_radio = cmds.radioButton(l="ローカル")
        self.ui_one_obj_cb = cmds.checkBox(l="１メッシュ", cc=self.ui_change)
        cmds.setParent("..")
        
        cmds.separator()
        cmds.setParent("..") # Top UI column

        # --- Middle UI (Primitive Buttons) ---
        cmds.columnLayout(adj=True)
        
        # Cube
        cmds.rowLayout(nc=5, adj=2)
        cmds.iconTextButton(i="polyCube.png", c=lambda *x: self.go(0))
        cmds.columnLayout(adj=True)
        cmds.text(l="", h=1) # Spacer
        cmds.setParent("..")
        cmds.setParent("..")
        cmds.separator()
        
        # Cylinder
        cmds.rowLayout(nc=5, adj=2)
        cmds.iconTextButton(i="polyCylinder.png", c=lambda *x: self.go(1))
        cmds.columnLayout(adj=True)
        self.ui_cylinder_int[0] = cmds.intSliderGrp(field=True, cw=(1, 30), w=30, h=20, v=8, min=6, max=64, fmx=64, ann=label_sub_axis)
        cmds.intSliderGrp(self.ui_cylinder_int[0], e=True, dc=lambda *x: self.validate_slider_step(self.ui_cylinder_int[0]))
        
        cylinder_popup = cmds.popupMenu(button=3)
        for val in [6,8,12,16,32,64]:
            cmds.menuItem(l=str(val), p=cylinder_popup, c=lambda x, v=val: self.int_value_change(1, 0, v))
        cmds.setParent("..")
        cmds.setParent("..")
        cmds.separator()
        
        # Sphere
        cmds.rowLayout(nc=5, adj=2)
        cmds.iconTextButton(i="polySphere.png", c=lambda *x: self.go(2))
        cmds.columnLayout(adj=True)
        self.ui_sphere_int[0] = cmds.intSliderGrp(field=True, cw=(1, 30), w=30, h=20, v=16, min=6, max=64, fmx=64, ann=label_sub_axis)
        cmds.intSliderGrp(self.ui_sphere_int[0], e=True, dc=lambda *x: self.validate_slider_step(self.ui_sphere_int[0]))
        sphere_popup0 = cmds.popupMenu(button=3)
        for val in [6,8,12,16,32,64]:
            cmds.menuItem(l=str(val), p=sphere_popup0, c=lambda x, v=val: self.int_value_change(2, 0, v))

        self.ui_sphere_int[1] = cmds.intSliderGrp(field=True, cw=(1, 30), w=30, h=20, v=16, min=6, max=64, fmx=64, ann=label_sub_height)
        cmds.intSliderGrp(self.ui_sphere_int[1], e=True, dc=lambda *x: self.validate_slider_step(self.ui_sphere_int[1]))
        sphere_popup1 = cmds.popupMenu(button=3)
        for val in [6,8,12,16,32,64]:
            cmds.menuItem(l=str(val), p=sphere_popup1, c=lambda x, v=val: self.int_value_change(2, 1, v))
            
        cmds.setParent("..")
        cmds.setParent("..")
        cmds.separator()
        cmds.setParent("..") # Middle UI column

        # --- Bottom UI (Move Buttons etc) ---
        cmds.columnLayout(adj=True)
        
        cmds.rowLayout(nc=3, adj=2)
        cmds.radioButtonGrp("MM_tool_Collider_UI_RadioBtn", numberOfRadioButtons=2, labelArray2=["ボックスの場合", "曲面がある場合"], select=1)
        cmds.setParent("..")
        
        def make_move_btn(label, direction):
            cmds.button(l=label, w=100, c=lambda *x: self.call_python_script(direction))
            
        cmds.rowLayout(nc=2, adj=2)
        make_move_btn("+1" + unit_label, "plus_1")
        make_move_btn("-1" + unit_label, "minus_1")
        cmds.setParent("..")
        
        cmds.rowLayout(nc=2, adj=2)
        make_move_btn("+0.5" + unit_label, "plus_0.5")
        make_move_btn("-0.5" + unit_label, "minus_0.5")
        cmds.setParent("..")

        cmds.rowLayout(nc=2, adj=2)
        make_move_btn("+0.25" + unit_label, "plus_0.25")
        make_move_btn("-0.25" + unit_label, "minus_0.25")
        cmds.setParent("..")

        cmds.rowLayout(nc=2, adj=2)
        make_move_btn("+0.1" + unit_label, "plus_0.1")
        make_move_btn("-0.1" + unit_label, "minus_0.1")
        cmds.setParent("..")
        
        cmds.rowLayout(nc=2, adj=2)
        make_move_btn("+0.05" + unit_label, "plus_0.05")
        make_move_btn("-0.05" + unit_label, "minus_0.05")
        cmds.setParent("..")
        
        cmds.setParent("..") # Bottom UI column
        cmds.setParent("..") # Main Layout

        cmds.showWindow(self.window_name)
        self.load_prefs(False)


def main():
    tool = MM_tool_Collider()
    tool.show_ui()

if __name__ == "__main__":
    main()
