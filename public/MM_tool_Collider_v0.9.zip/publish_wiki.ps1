# Wiki Publish Script
# Copies content from Dev Repo (wiki folder) to Public Repo (Root) and pushes to GitHub.

$sourceDir = "$PSScriptRoot\wiki"
$destDir = "$PSScriptRoot\..\MM_tool_Collider_wiki"

# Ensure destination exists
if (-not (Test-Path $destDir)) {
    Write-Error "Destination directory not found: $destDir"
    exit 1
}

Write-Host "Syncing Wiki Content..." -ForegroundColor Cyan
Write-Host "Source: $sourceDir"
Write-Host "Dest:   $destDir"

# Copy files using Robocopy for robust mirroring
# /MIR :: Mirror a directory tree
# /XD  :: Exclude directories (.git, node_modules)
# /XF  :: Exclude files
# /NJH /NJS /NDL /NC /NS :: Reduce output noise
robocopy $sourceDir $destDir /MIR /XD ".git" "node_modules" ".idea" ".vscode" /XF ".gitignore" /NJH /NJS /NDL /NC /NS

# Check if robocopy failed (Exit codes 0-7 are success/partial success)
if ($LASTEXITCODE -gt 7) {
    Write-Error "Robocopy failed with exit code $LASTEXITCODE"
    exit 1
}

Write-Host "Content synced. Checking for changes..." -ForegroundColor Cyan

# Change to destination directory
Push-Location $destDir

# Git operations
git add .
$status = git status --porcelain

if (-not $status) {
    Write-Host "No changes detected. Wiki is up to date." -ForegroundColor Yellow
    Pop-Location
    Pause
    exit 0
}

Write-Host "Changes detected. Preparing to push..." -ForegroundColor Cyan

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
git commit -m "Update Wiki: $timestamp"

Write-Host "Pushing to GitHub..." -ForegroundColor Cyan
git push origin main

if ($?) {
    Write-Host "Wiki successfully published!" -ForegroundColor Green
    Write-Host "Check deployment status here: https://github.com/KuroSiro0112/MM_tool_Collider_wiki/actions" -ForegroundColor Cyan
} else {
    Write-Error "Failed to push to GitHub."
}

Pop-Location
Pause
