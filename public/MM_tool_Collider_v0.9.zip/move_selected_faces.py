import maya.cmds as cmds
import maya.OpenMaya as om
import maya.mel as mel

def get_face_normal(face):
    sel_list = om.MSelectionList()
    sel_list.add(face)
    dag_path = om.MDagPath()
    component = om.MObject()
    sel_list.getDagPath(0, dag_path, component)
    face_iter = om.MItMeshPolygon(dag_path, component)
    normal = om.MVector()
    face_iter.getNormal(normal, om.MSpace.kWorld)
    return [normal.x, normal.y, normal.z]

def move_selected_faces(direction='plus_4', mode_override=None):
    if mode_override:
        mode = mode_override
    else:
        mode_index = mel.eval('radioButtonGrp -q -select MM_tool_Collider_UI_RadioBtn')
        mode = 'box' if mode_index == 1 else 'surface'
    current_unit = cmds.currentUnit(query=True, linear=True)
    
    # directionから数値を抽出 (例: 'plus_4' -> 4.0)
    # The value extracted is assumed to be in METERS (e.g. 1.5 from "plus_1.5" corresponds to "1.5m" in UI)
    try:
        dist_str = direction.split('_')[-1]
        move_distance = float(dist_str)
    except (ValueError, IndexError):
        move_distance = 0.4 # Default to 0.4 meters if parsing fails

    # Convert from Meters to Current Scene Unit
    if current_unit == 'cm':
        move_distance *= 100.0
    elif current_unit == 'mm':
        move_distance *= 1000.0
    # If unit is 'm', no change needed
    
    if "minus" in direction:
        move_distance *= -1

    selected_faces = cmds.filterExpand(sm=34)
    if not selected_faces:
        cmds.warning("面が選択されていません。移動する面を選択してください。")
        return

    if mode == 'box':
        for face in selected_faces:
            normal = get_face_normal(face)
            move_vector = [normal[0] * move_distance, normal[1] * move_distance, normal[2] * move_distance]
            vertices = cmds.polyListComponentConversion(face, toVertex=True)
            vertices = cmds.filterExpand(vertices, sm=31)
            
            if vertices:
                cmds.select(vertices, replace=True)
                cmds.move(move_vector[0], move_vector[1], move_vector[2], vertices, relative=True, worldSpace=True)
        cmds.select(selected_faces, replace=True)  # 元のフェース選択状態に戻す
    else:
        move_facet_name = cmds.polyMoveFacet(selected_faces, constructionHistory=True, random=0)[0]
        cmds.setAttr(f"{move_facet_name}.ltz", move_distance)
        cmds.select(selected_faces, replace=True)  # 元のフェース選択状態に戻す


